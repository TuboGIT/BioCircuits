/**
 * axon.js — Module 3: Nerve Signal as a Transmission Line
 *
 * Physics Model (Simplified Cable Theory):
 *   - Unmyelinated axon conduction velocity scales with sqrt(diameter):
 *       v_unmyel = 1.0 * sqrt(d_um)  [m/s]
 *   - Myelinated axon conduction velocity scales with outer fiber diameter
 *     and insulation effectiveness (decreasing effective C_m, increasing length constant):
 *       v_myel = v_unmyel + 5.2 * (d_um + 2 * myelin_um) * insulationFactor  [m/s]
 *
 * Visualizes a 100 mm axon segment in scaled slow-motion (14 ms of nerve time
 * per real second) so the user can watch saltatory conduction leap across
 * Nodes of Ranvier while the unmyelinated signal crawls continuously.
 */
(function (Bio) {
  "use strict";

  const ACCENT = Bio.COLORS.accent;
  const AXON_LEN_MM = 100;     // 100 mm (10 cm) track
  const NODE_SPACING_MM = 10;  // Node of Ranvier every 10 mm (scaled visually)
  const SIM_MS_PER_SEC = 14;   // Slow-motion playback rate (ms/s)

  const params = {
    diamUm: 6.0,
    myelinUm: 2.0,
    autoRepeat: true
  };

  const state = {
    elapsedMs: 0,
    myelPosMm: 0,
    unmyelPosMm: 0,
    myelDone: false,
    unmyelDone: false,
    pauseTimerMs: 0
  };

  let raceCanvas, waveCanvas;
  let diamSlider, myelinSlider, autoRepeatToggle;

  /**
   * Compute conduction speeds (m/s) and cable metrics from diameter & myelin.
   */
  function computeMetrics() {
    const d = params.diamUm;
    const w = params.myelinUm;

    // Unmyelinated velocity: ~1.0 m/s at 1 µm, ~3.2 m/s at 10 µm
    const vUnmyel = 1.0 * Math.sqrt(d);

    // Insulation factor approaches 1 as myelin thickens relative to core
    const insulation = w <= 0 ? 0 : 1 - Math.exp(-w / (0.18 * d + 0.35));
    const outerD = d + 2 * w;
    // Hursh-inspired myelinated scaling (capped around ~125 m/s)
    const vMyel = Math.min(125, vUnmyel + 4.4 * outerD * insulation);

    const gRatio = d / outerD;
    // Standard bare membrane C_m ~ 1.0 µF/cm²; myelin reduces effective C_m
    const effCm = 1.0 / (1 + 9.5 * w);
    const lambdaMm = 0.7 * Math.sqrt(d) * (1 + 1.5 * w);

    return { vMyel, vUnmyel, gRatio, effCm, lambdaMm };
  }

  function resetRace() {
    state.elapsedMs = 0;
    state.myelPosMm = 0;
    state.unmyelPosMm = 0;
    state.myelDone = false;
    state.unmyelDone = false;
    state.pauseTimerMs = 0;
  }

  function syncUI() {
    const m = computeMetrics();
    document.getElementById("val-diam").textContent = `${params.diamUm.toFixed(1)} µm`;
    document.getElementById("val-myelin").textContent = `${params.myelinUm.toFixed(1)} µm`;

    document.getElementById("axon-myel-speed").textContent = `${m.vMyel.toFixed(1)} m/s`;
    document.getElementById("axon-unmyel-speed").textContent = `${m.vUnmyel.toFixed(1)} m/s`;
    document.getElementById("axon-ratio-readout").textContent = `${(m.vMyel / m.vUnmyel).toFixed(1)}×`;

    document.getElementById("axon-gratio-chip").textContent = `g-ratio = ${m.gRatio.toFixed(2)}`;
    document.getElementById("axon-cm-metric").textContent = `${m.effCm.toFixed(2)} µF/cm²`;
    document.getElementById("axon-lambda-metric").textContent = `${m.lambdaMm.toFixed(1)} mm`;

    // Note: 1 m/s = 1 mm/ms, so travel time across 100 mm is 100 / speed (ms)
    const tMyelMs = AXON_LEN_MM / m.vMyel;
    const tUnmyelMs = AXON_LEN_MM / m.vUnmyel;
    document.getElementById("axon-eta-metric").textContent =
      Bio.t("a.vs", { t1: tMyelMs.toFixed(1), t2: tUnmyelMs.toFixed(1) });
  }

  function init() {
    raceCanvas = document.getElementById("axon-race");
    waveCanvas = document.getElementById("axon-wave");
    diamSlider = document.getElementById("slider-diam");
    myelinSlider = document.getElementById("slider-myelin");
    autoRepeatToggle = document.getElementById("axon-autorepeat");

    diamSlider.addEventListener("input", () => {
      params.diamUm = parseFloat(diamSlider.value);
      syncUI();
    });
    myelinSlider.addEventListener("input", () => {
      params.myelinUm = parseFloat(myelinSlider.value);
      syncUI();
    });
    autoRepeatToggle.addEventListener("change", () => {
      params.autoRepeat = autoRepeatToggle.checked;
    });

    document.getElementById("axon-fire-btn").addEventListener("click", resetRace);

    syncUI();
    resetRace();
  }

  function update(dtSec) {
    const dtMs = dtSec * SIM_MS_PER_SEC;
    const m = computeMetrics();

    if (!state.myelDone || !state.unmyelDone) {
      state.elapsedMs += dtMs;
      // 1 m/s equals exactly 1 mm/ms
      state.myelPosMm = Math.min(AXON_LEN_MM, state.myelPosMm + m.vMyel * dtMs);
      state.unmyelPosMm = Math.min(AXON_LEN_MM, state.unmyelPosMm + m.vUnmyel * dtMs);

      if (state.myelPosMm >= AXON_LEN_MM) state.myelDone = true;
      if (state.unmyelPosMm >= AXON_LEN_MM) state.unmyelDone = true;
    } else if (params.autoRepeat) {
      state.pauseTimerMs += dtSec * 1000;
      if (state.pauseTimerMs > 900) {
        resetRace();
      }
    }

    document.getElementById("axon-time-chip").textContent =
      Bio.t("a.elapsed", { t: state.elapsedMs.toFixed(1) });
  }

  /**
   * Draw the two physical axon tracks (myelinated with Nodes of Ranvier vs. bare).
   */
  function drawRace() {
    const W = 760;
    const H = 230;
    const ctx = Bio.fitCanvas(raceCanvas, W, H);
    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);

    const padL = 60;
    const padR = 30;
    const trackW = W - padL - padR;
    const mapX = (mm) => padL + (mm / AXON_LEN_MM) * trackW;

    const m = computeMetrics();
    const coreH = Math.max(8, Math.min(26, 6 + params.diamUm * 0.95));
    const sheathPad = Math.max(0, params.myelinUm * 2.6);

    // Distance ruler along bottom
    ctx.strokeStyle = "rgba(144, 164, 186, 0.18)";
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "10px ui-monospace, monospace";
    ctx.textAlign = "center";
    for (let mm = 0; mm <= AXON_LEN_MM; mm += 20) {
      const x = Math.round(mapX(mm)) + 0.5;
      ctx.beginPath();
      ctx.moveTo(x, 24);
      ctx.lineTo(x, H - 24);
      ctx.stroke();
      ctx.fillText(`${mm} mm`, x, H - 8);
    }

    // --- Track 1: Myelinated Axon ---
    const yMyel = 66;
    ctx.textAlign = "left";
    ctx.fillStyle = ACCENT;
    ctx.font = "bold 12px system-ui, sans-serif";
    ctx.fillText(Bio.t("a.trackMyel", { v: m.vMyel.toFixed(1) }), padL, 26);

    // Inner core
    ctx.fillStyle = "#192638";
    ctx.strokeStyle = "#324761";
    ctx.lineWidth = 1.2;
    ctx.fillRect(padL, yMyel - coreH / 2, trackW, coreH);
    ctx.strokeRect(padL, yMyel - coreH / 2, trackW, coreH);

    // Myelin sheath blocks separated by Nodes of Ranvier
    if (params.myelinUm > 0.05) {
      const nodeGapPx = 10;
      for (let mm = 0; mm < AXON_LEN_MM; mm += NODE_SPACING_MM) {
        const x1 = mapX(mm) + (mm === 0 ? 0 : nodeGapPx / 2);
        const x2 = mapX(mm + NODE_SPACING_MM) - (mm + NODE_SPACING_MM >= AXON_LEN_MM ? 0 : nodeGapPx / 2);
        const segW = Math.max(4, x2 - x1);

        ctx.fillStyle = "rgba(144, 164, 186, 0.22)";
        ctx.strokeStyle = "rgba(144, 164, 186, 0.5)";
        ctx.beginPath();
        ctx.roundRect(x1, yMyel - coreH / 2 - sheathPad, segW, coreH + sheathPad * 2, 5);
        ctx.fill();
        ctx.stroke();
      }
    }

    // Glowing Nodes of Ranvier when pulse passes nearby
    for (let mm = NODE_SPACING_MM; mm < AXON_LEN_MM; mm += NODE_SPACING_MM) {
      const nx = mapX(mm);
      const dist = Math.abs(state.myelPosMm - mm);
      if (dist < 7 && !state.myelDone) {
        ctx.save();
        ctx.fillStyle = ACCENT;
        ctx.shadowColor = ACCENT;
        ctx.shadowBlur = 14;
        ctx.beginPath();
        ctx.arc(nx, yMyel, 5, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      }
    }

    // Traveling pulse wave inside myelinated axon
    {
      const px = mapX(state.myelPosMm);
      const grad = ctx.createRadialGradient(px, yMyel, 2, px, yMyel, 32);
      grad.addColorStop(0, "rgba(0, 229, 163, 0.95)");
      grad.addColorStop(0.5, "rgba(0, 229, 163, 0.35)");
      grad.addColorStop(1, "rgba(0, 229, 163, 0)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(px, yMyel, 32, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = ACCENT;
      ctx.beginPath();
      ctx.arc(px, yMyel, 5.5, 0, Math.PI * 2);
      ctx.fill();
    }

    // --- Track 2: Unmyelinated Axon ---
    const yUnmyel = 158;
    ctx.textAlign = "left";
    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "bold 12px system-ui, sans-serif";
    ctx.fillText(Bio.t("a.trackUnmyel", { v: m.vUnmyel.toFixed(1) }), padL, 122);

    ctx.fillStyle = "#192638";
    ctx.strokeStyle = "#485f7a";
    ctx.lineWidth = 1.4;
    ctx.fillRect(padL, yUnmyel - coreH / 2, trackW, coreH);
    ctx.strokeRect(padL, yUnmyel - coreH / 2, trackW, coreH);

    // Traveling pulse along unmyelinated axon
    {
      const px = mapX(state.unmyelPosMm);
      const grad = ctx.createRadialGradient(px, yUnmyel, 2, px, yUnmyel, 22);
      grad.addColorStop(0, "rgba(232, 238, 246, 0.95)");
      grad.addColorStop(0.6, "rgba(232, 238, 246, 0.28)");
      grad.addColorStop(1, "rgba(232, 238, 246, 0)");
      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(px, yUnmyel, 22, 0, Math.PI * 2);
      ctx.fill();

      ctx.fillStyle = "#e8eef6";
      ctx.beginPath();
      ctx.arc(px, yUnmyel, 5, 0, Math.PI * 2);
      ctx.fill();
    }
  }

  /**
   * Draw spatial voltage waveform V(x) in mV across the 0–100 mm axon.
   */
  function drawWaveProfile() {
    const W = 760;
    const H = 200;
    const ctx = Bio.fitCanvas(waveCanvas, W, H);
    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);

    const pad = { left: 58, right: 30, top: 18, bottom: 34 };
    const pw = W - pad.left - pad.right;
    const ph = H - pad.top - pad.bottom;

    Bio.drawGrid(ctx, pad.left, pad.top, pw, ph, 10, 6, 2);

    const vMin = -90;
    const vMax = 50;
    const mapX = (mm) => pad.left + (mm / AXON_LEN_MM) * pw;
    const mapY = (mv) => pad.top + ((vMax - mv) / (vMax - vMin)) * ph;

    // Axes labels
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "11px ui-monospace, monospace";
    ctx.textAlign = "right";
    [-70, 0, 40].forEach((v) => {
      ctx.fillText(`${v} mV`, pad.left - 8, mapY(v) + 4);
    });

    ctx.textAlign = "center";
    for (let mm = 0; mm <= AXON_LEN_MM; mm += 20) {
      ctx.fillText(`${mm} mm`, mapX(mm), pad.top + ph + 15);
    }

    // Spatial action potential shape centered at posMm with spatial width sigmaMm
    function apVoltageAt(xMm, centerMm, sigmaMm) {
      const dx = xMm - centerMm;
      const spike = 105 * Math.exp(-0.5 * Math.pow(dx / sigmaMm, 2));
      // Trailing hyperpolarization behind the wave (to the left)
      const trail = -12 * Math.exp(-0.5 * Math.pow((dx + sigmaMm * 2.1) / (sigmaMm * 1.1), 2));
      return -70 + spike + trail;
    }

    const m = computeMetrics();
    const sigmaMyel = Math.max(2.5, Math.min(9.5, m.lambdaMm * 1.3));
    const sigmaUnmyel = 2.2;

    // Draw unmyelinated wave (white)
    ctx.save();
    ctx.beginPath();
    ctx.rect(pad.left, pad.top, pw, ph);
    ctx.clip();

    ctx.strokeStyle = "rgba(232, 238, 246, 0.85)";
    ctx.lineWidth = 2;
    ctx.beginPath();
    for (let mm = 0; mm <= AXON_LEN_MM; mm += 0.5) {
      const x = mapX(mm);
      const y = mapY(apVoltageAt(mm, state.unmyelPosMm, sigmaUnmyel));
      if (mm === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();

    // Draw myelinated wave (bright accent)
    ctx.strokeStyle = ACCENT;
    ctx.lineWidth = 2.5;
    ctx.shadowColor = "rgba(0, 229, 163, 0.45)";
    ctx.shadowBlur = 7;
    ctx.beginPath();
    for (let mm = 0; mm <= AXON_LEN_MM; mm += 0.5) {
      const x = mapX(mm);
      const y = mapY(apVoltageAt(mm, state.myelPosMm, sigmaMyel));
      if (mm === 0) ctx.moveTo(x, y);
      else ctx.lineTo(x, y);
    }
    ctx.stroke();
    ctx.restore();
  }

  function draw() {
    drawRace();
    drawWaveProfile();
  }

  Bio.registerModule("axon", {
    init,
    update,
    draw,
    onShow: draw,
    onLangChange: () => {
      syncUI();
      document.getElementById("axon-time-chip").textContent =
        Bio.t("a.elapsed", { t: state.elapsedMs.toFixed(1) });
      draw();
    }
  });
})(window.BioCircuits);
