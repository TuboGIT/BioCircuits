/**
 * heart.js — Module 2: Heart as an Oscillator
 *
 * Physics / Signal Model:
 * Models the cardiac conduction system as a three-stage electronic circuit:
 *   1. SA Node Relaxation Oscillator -> fires at period T = 60,000 / BPM (ms)
 *      generating an atrial P-wave pulse of width `pacemakerTimingMs`.
 *   2. AV Node RC Delay Line -> delays conduction by `conductionDelayMs`.
 *      When delay > 290 ms, refractory gating drops every second beat (2:1 AV Block).
 *   3. His-Purkinje Driver & Recovery -> synthesizes the QRS complex and T wave.
 */
(function (Bio) {
  "use strict";

  const ACCENT = Bio.COLORS.accent;
  const WINDOW_MS = 4000; // 4.0 seconds visible on the ECG monitor

  const PRESETS = {
    normal: { hr: 72, pWidth: 100, avDelay: 160, label: "Normal Sinus" },
    tachy: { hr: 138, pWidth: 80, avDelay: 120, label: "Tachycardia" },
    brady: { hr: 42, pWidth: 125, avDelay: 185, label: "Bradycardia" },
    block: { hr: 76, pWidth: 100, avDelay: 330, label: "2:1 Heart Block" }
  };

  const params = {
    hr: 72,
    pWidth: 100,
    avDelay: 160
  };

  const state = {
    tMs: 0,
    nextBeatMs: 150,
    beatCounter: 0,
    // Scheduled wave events: { kind: 'P'|'QRS'|'T'|'BLOCKED', centerMs, widthMs }
    events: [],
    // Ring buffer of { t, mV }
    samples: [],
    // Flash timers (ms) for visual conduction chain blocks
    saFlash: 0,
    avFlash: 0,
    ventFlash: 0
  };

  let ecgCanvas, chainCanvas;
  let bpmReadout, periodReadout, statusReadout, chainChip;
  let hrSlider, pWidthSlider, avDelaySlider;

  function gaussian(dt, sigma) {
    const x = dt / sigma;
    return Math.exp(-0.5 * x * x);
  }

  /**
   * Evaluate ECG voltage (mV) at time tMs by summing active P, QRS, T waves.
   */
  function evaluateEcgMv(tMs) {
    let mv = 0;

    for (let i = 0; i < state.events.length; i++) {
      const ev = state.events[i];
      const dt = tMs - ev.centerMs;
      if (Math.abs(dt) > 450) continue;

      if (ev.kind === "P") {
        // P wave width scales with Pacemaker Timing slider
        const sigma = ev.widthMs * 0.24;
        mv += 0.18 * gaussian(dt, sigma);
      } else if (ev.kind === "QRS") {
        // Q dip, tall R peak, S dip
        mv -= 0.16 * gaussian(dt + 20, 7.5);
        mv += 1.25 * gaussian(dt, 9.5);
        mv -= 0.28 * gaussian(dt - 22, 8.5);
      } else if (ev.kind === "T") {
        // Slightly asymmetric repolarization T wave
        const sigma = dt < 0 ? 44 : 32;
        mv += 0.34 * gaussian(dt, sigma);
      }
    }

    // Tiny baseline micro-noise for realistic monitor feel
    mv += Math.sin(tMs * 0.037) * 0.008;
    return mv;
  }

  /**
   * Schedule one SA oscillator cycle and (if not blocked) its downstream QRS + T.
   */
  function triggerBeat(pCenterMs) {
    state.beatCounter += 1;
    state.saFlash = 160;

    state.events.push({
      kind: "P",
      centerMs: pCenterMs,
      widthMs: params.pWidth,
      label: "P"
    });

    // Heart block threshold: above 290 ms, every 2nd beat is dropped at the AV node
    const isBlocked = params.avDelay > 290 && state.beatCounter % 2 === 0;
    if (isBlocked) {
      state.events.push({
        kind: "BLOCKED",
        centerMs: pCenterMs + params.avDelay * 0.55,
        widthMs: 40,
        label: "AV Blocked"
      });
      return;
    }

    const qrsCenterMs = pCenterMs + params.avDelay;
    // QT interval shortens mildly at faster heart rates (Bazett-inspired scaling)
    const rrMs = 60000 / params.hr;
    const qtDelay = Math.max(170, Math.min(290, 220 * Math.sqrt(rrMs / 833)));

    state.events.push({
      kind: "QRS",
      centerMs: qrsCenterMs,
      widthMs: 70,
      label: "QRS"
    });
    state.events.push({
      kind: "T",
      centerMs: qrsCenterMs + qtDelay,
      widthMs: 120,
      label: "T"
    });
  }

  function updatePresetHighlight() {
    document.querySelectorAll("#heart-presets .btn-preset").forEach((btn) => {
      const p = PRESETS[btn.dataset.preset];
      const match =
        p &&
        Math.abs(params.hr - p.hr) <= 1 &&
        Math.abs(params.pWidth - p.pWidth) <= 1 &&
        Math.abs(params.avDelay - p.avDelay) <= 1;
      btn.classList.toggle("is-selected", Boolean(match));
    });
  }

  function getRhythmStatus() {
    if (params.avDelay > 290) return Bio.t("h.statusBlock");
    if (params.avDelay > 220) return Bio.t("h.statusDelay1");
    if (params.hr > 100) return Bio.t("h.statusTachy");
    if (params.hr < 60) return Bio.t("h.statusBrady");
    return Bio.t("h.statusNormal");
  }

  function syncUI() {
    document.getElementById("val-hr").textContent = `${params.hr} BPM`;
    document.getElementById("val-pwidth").textContent = `${params.pWidth} ms`;
    document.getElementById("val-avdelay").textContent = `${params.avDelay} ms`;

    const periodMs = Math.round(60000 / params.hr);
    bpmReadout.textContent = `${params.hr} BPM`;
    periodReadout.textContent = `${periodMs} ms`;
    statusReadout.textContent = getRhythmStatus();
    chainChip.textContent = params.avDelay > 290 ? Bio.t("h.chipBlock") : `PR = ${params.avDelay} ms`;

    updatePresetHighlight();
  }

  function applyPreset(key) {
    const p = PRESETS[key];
    if (!p) return;
    params.hr = p.hr;
    params.pWidth = p.pWidth;
    params.avDelay = p.avDelay;

    hrSlider.value = p.hr;
    pWidthSlider.value = p.pWidth;
    avDelaySlider.value = p.avDelay;
    syncUI();
  }

  function init() {
    ecgCanvas = document.getElementById("heart-ecg");
    chainCanvas = document.getElementById("heart-chain");
    bpmReadout = document.getElementById("heart-bpm-readout");
    periodReadout = document.getElementById("heart-period-readout");
    statusReadout = document.getElementById("heart-status-readout");
    chainChip = document.getElementById("heart-chain-chip");

    hrSlider = document.getElementById("slider-hr");
    pWidthSlider = document.getElementById("slider-pwidth");
    avDelaySlider = document.getElementById("slider-avdelay");

    hrSlider.addEventListener("input", () => {
      params.hr = parseInt(hrSlider.value, 10);
      syncUI();
    });
    pWidthSlider.addEventListener("input", () => {
      params.pWidth = parseInt(pWidthSlider.value, 10);
      syncUI();
    });
    avDelaySlider.addEventListener("input", () => {
      params.avDelay = parseInt(avDelaySlider.value, 10);
      syncUI();
    });

    document.querySelectorAll("#heart-presets .btn-preset").forEach((btn) => {
      btn.addEventListener("click", () => applyPreset(btn.dataset.preset));
    });

    // Pre-populate 4 seconds of baseline samples so graph looks rich on first open
    state.tMs = 0;
    state.nextBeatMs = -3200;
    while (state.nextBeatMs < 200) {
      triggerBeat(state.nextBeatMs);
      state.nextBeatMs += 60000 / params.hr;
    }
    for (let t = -WINDOW_MS; t <= 0; t += 8) {
      state.samples.push({ t, mv: evaluateEcgMv(t) });
    }

    syncUI();
  }

  function update(dtSec) {
    const dtMs = dtSec * 1000;
    const targetT = state.tMs + dtMs;

    // Step in 6 ms increments so fast R spikes are always cleanly sampled
    while (state.tMs < targetT) {
      state.tMs = Math.min(targetT, state.tMs + 6);

      while (state.tMs >= state.nextBeatMs) {
        triggerBeat(state.nextBeatMs + 80);
        state.nextBeatMs += 60000 / params.hr;
      }

      // Check active events for conduction chain flashes
      for (let i = 0; i < state.events.length; i++) {
        const ev = state.events[i];
        if (Math.abs(state.tMs - ev.centerMs) < 12) {
          if (ev.kind === "P") state.avFlash = params.avDelay;
          if (ev.kind === "QRS") state.ventFlash = 180;
        }
      }

      state.samples.push({ t: state.tMs, mv: evaluateEcgMv(state.tMs) });
    }

    state.saFlash = Math.max(0, state.saFlash - dtMs);
    state.avFlash = Math.max(0, state.avFlash - dtMs);
    state.ventFlash = Math.max(0, state.ventFlash - dtMs);

    // Prune old samples & events
    const minT = state.tMs - WINDOW_MS - 400;
    while (state.samples.length > 2 && state.samples[0].t < minT) {
      state.samples.shift();
    }
    while (state.events.length > 0 && state.events[0].centerMs < minT) {
      state.events.shift();
    }
  }

  function drawEcg() {
    const W = 760;
    const H = 320;
    const ctx = Bio.fitCanvas(ecgCanvas, W, H);

    const pad = { left: 58, right: 20, top: 24, bottom: 38 };
    const pw = W - pad.left - pad.right;
    const ph = H - pad.top - pad.bottom;

    const mvMin = -0.6;
    const mvMax = 1.6;
    const mapY = (mv) => pad.top + ((mvMax - mv) / (mvMax - mvMin)) * ph;
    const tEnd = state.tMs;
    const tStart = tEnd - WINDOW_MS;
    const mapX = (t) => pad.left + ((t - tStart) / WINDOW_MS) * pw;

    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);

    // 20 cols = 200 ms per box across 4000 ms; 11 rows = 0.2 mV per box
    Bio.drawGrid(ctx, pad.left, pad.top, pw, ph, 20, 11, 5);

    // 0 mV isoelectric line
    const zeroY = Math.round(mapY(0)) + 0.5;
    ctx.strokeStyle = "rgba(144, 164, 186, 0.25)";
    ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(pad.left, zeroY);
    ctx.lineTo(pad.left + pw, zeroY);
    ctx.stroke();

    // Y-axis ticks & label (mV)
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "11px ui-monospace, Consolas, monospace";
    ctx.textAlign = "right";
    [-0.5, 0, 0.5, 1.0, 1.5].forEach((v) => {
      ctx.fillText(v.toFixed(1), pad.left - 8, mapY(v) + 4);
    });

    ctx.save();
    ctx.translate(16, pad.top + ph / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = "center";
    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText(Bio.t("h.axisY"), 0, 0);
    ctx.restore();

    // X-axis ticks (ms)
    ctx.textAlign = "center";
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "11px ui-monospace, Consolas, monospace";
    for (let ms = 0; ms <= WINDOW_MS; ms += 1000) {
      const x = pad.left + (ms / WINDOW_MS) * pw;
      const label = ms === WINDOW_MS ? "0 ms" : `-${WINDOW_MS - ms}`;
      ctx.fillText(label, x, pad.top + ph + 16);
    }
    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText(Bio.t("h.axisX"), pad.left + pw / 2, H - 6);

    // Draw ECG waveform
    ctx.save();
    ctx.beginPath();
    ctx.rect(pad.left, pad.top, pw, ph);
    ctx.clip();

    ctx.strokeStyle = ACCENT;
    ctx.lineWidth = 2.4;
    ctx.lineJoin = "round";
    ctx.shadowColor = "rgba(0, 229, 163, 0.45)";
    ctx.shadowBlur = 7;

    ctx.beginPath();
    state.samples.forEach((pt, idx) => {
      const px = mapX(pt.t);
      const py = mapY(pt.mv);
      if (idx === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();

    // Wave annotations (P, QRS, T, AV Blocked) on visible events
    ctx.shadowBlur = 0;
    ctx.font = "bold 11px ui-monospace, monospace";
    ctx.textAlign = "center";
    state.events.forEach((ev) => {
      if (ev.centerMs < tStart + 60 || ev.centerMs > tEnd - 40) return;
      const x = mapX(ev.centerMs);
      if (ev.kind === "P") {
        ctx.fillStyle = Bio.COLORS.muted;
        ctx.fillText("P", x, mapY(0.28));
      } else if (ev.kind === "QRS") {
        ctx.fillStyle = ACCENT;
        ctx.fillText("QRS", x, mapY(1.36));
      } else if (ev.kind === "T") {
        ctx.fillStyle = Bio.COLORS.muted;
        ctx.fillText("T", x, mapY(0.45));
      } else if (ev.kind === "BLOCKED") {
        ctx.fillStyle = Bio.COLORS.warn;
        ctx.fillText(Bio.t("h.blocked"), x, mapY(0.55));
      }
    });

    ctx.restore();
  }

  /**
   * Draw the 3-stage electronic conduction block diagram that lights up in sync.
   */
  function drawChain() {
    const W = 420;
    const H = 170;
    const ctx = Bio.fitCanvas(chainCanvas, W, H);
    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);

    const blocks = [
      {
        x: 20,
        title: Bio.t("h.chainSa"),
        sub: Bio.t("h.chainSaSub"),
        val: `${params.hr} BPM`,
        active: state.saFlash > 0
      },
      {
        x: 155,
        title: Bio.t("h.chainAv"),
        sub: Bio.t("h.chainAvSub"),
        val: `${params.avDelay} ms`,
        active: state.avFlash > 0,
        warn: params.avDelay > 290
      },
      {
        x: 290,
        title: Bio.t("h.chainVent"),
        sub: Bio.t("h.chainVentSub"),
        val: params.avDelay > 290 ? Bio.t("h.chainBeat21") : Bio.t("h.chainSync11"),
        active: state.ventFlash > 0
      }
    ];

    // Connecting arrows
    ctx.strokeStyle = "#3a4f66";
    ctx.lineWidth = 2;
    [130, 265].forEach((ax) => {
      ctx.beginPath();
      ctx.moveTo(ax, 84);
      ctx.lineTo(ax + 25, 84);
      ctx.lineTo(ax + 19, 78);
      ctx.moveTo(ax + 25, 84);
      ctx.lineTo(ax + 19, 90);
      ctx.stroke();
    });

    blocks.forEach((b) => {
      ctx.save();
      const borderColor = b.warn ? Bio.COLORS.warn : b.active ? ACCENT : "#2a3b50";
      ctx.fillStyle = b.active ? "rgba(0, 229, 163, 0.14)" : "#111824";
      ctx.strokeStyle = borderColor;
      ctx.lineWidth = b.active ? 2.2 : 1.4;

      ctx.beginPath();
      ctx.roundRect(b.x, 34, 110, 100, 10);
      ctx.fill();
      ctx.stroke();

      ctx.textAlign = "center";
      ctx.fillStyle = b.active ? ACCENT : Bio.COLORS.text;
      ctx.font = "bold 12px system-ui, sans-serif";
      ctx.fillText(b.title, b.x + 55, 62);

      ctx.fillStyle = Bio.COLORS.muted;
      ctx.font = "11px system-ui, sans-serif";
      ctx.fillText(b.sub, b.x + 55, 82);

      ctx.fillStyle = b.warn ? Bio.COLORS.warn : ACCENT;
      ctx.font = "bold 11px ui-monospace, monospace";
      ctx.fillText(b.val, b.x + 55, 112);
      ctx.restore();
    });
  }

  function draw() {
    drawEcg();
    drawChain();
  }

  Bio.registerModule("heart", {
    init,
    update,
    draw,
    onShow: draw,
    onLangChange: () => {
      syncUI();
      draw();
    }
  });
})(window.BioCircuits);
