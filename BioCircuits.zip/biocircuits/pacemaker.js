/**
 * pacemaker.js — Module 4: Pacemaker & Defibrillator Sandbox
 *
 * Physics / Circuit Model:
 *   - Energy Storage: E = 0.5 * C * V^2, with C = 150 µF (0.00015 F)
 *     so Capacitor Voltage V = sqrt(2 * E / C).
 *   - Discharge into Thorax Load (R_load = 50 Ω):
 *     RC discharge time constant tau = R_load * C = 50 * 150e-6 = 7.5 ms.
 *   - Arrhythmia & Reset Dynamics:
 *     * VFib: Chaotic sum of asynchronous oscillators; requires E >= 150 J
 *       to simultaneously depolarize all tissue and restore Normal Sinus.
 *     * VTach: Fast re-entrant 165 BPM wide-QRS rhythm; requires E >= 100 J
 *       to cardiovert back to Normal Sinus.
 *     * Sinus Pause (Slow Bradycardia): 34 BPM escape rhythm; enabling
 *       Demand Auto-Pacemaker (or delivering manual pulses) captures a QRS
 *       whenever no natural beat arrives within `timingMs`.
 */
(function (Bio) {
  "use strict";

  const ACCENT = Bio.COLORS.accent;
  const WINDOW_MS = 4000;
  const CAP_UF = 150;         // 150 µF storage capacitor
  const R_LOAD_OHM = 50;      // 50 Ω thoracic resistance

  const params = {
    energyJ: 200,
    timingMs: 800,
    autoPace: false
  };

  const state = {
    tMs: 0,
    rhythm: "vfib",           // 'vfib' | 'vtach' | 'brady' | 'sinus' | 'resetting'
    resetUntilMs: 0,
    nextNaturalBeatMs: 300,
    lastBeatMs: -500,
    pendingDelayTimerMs: -1,  // Countdown for timed manual discharge
    switchFlashMs: 0,
    capCharge: 1.0,           // 0..1 visual capacitor charge level
    events: [],               // { kind: 'P'|'QRS'|'T'|'VT'|'SPIKE', centerMs, amp }
    samples: [],
    feedbackKey: "p.fbDefault",
    feedbackVars: {}
  };

  let ecgCanvas, circuitCanvas;
  let energySlider, timingSlider, autoPaceToggle;
  let stateReadout, energyReadout, voltReadout, feedbackEl;

  function gaussian(dt, sigma) {
    const x = dt / sigma;
    return Math.exp(-0.5 * x * x);
  }

  function capacitorVoltageV() {
    // E = 0.5 * C * V^2 => V = sqrt(2 * E / C)
    const cFarads = CAP_UF * 1e-6;
    return Math.sqrt((2 * params.energyJ) / cFarads);
  }

  function evaluateSignalMv(tMs) {
    // During post-shock refractory pause: flat isoelectric line
    if (state.rhythm === "resetting") {
      return Math.sin(tMs * 0.04) * 0.01;
    }

    let mv = 0;

    // Chaotic baseline for VFib
    if (state.rhythm === "vfib") {
      mv +=
        0.24 * Math.sin(tMs * 0.031) +
        0.18 * Math.sin(tMs * 0.053 + 1.3) +
        0.13 * Math.cos(tMs * 0.079 + 0.7) +
        0.08 * Math.sin(tMs * 0.113);
    }

    // Sum scheduled discrete wave events (Sinus beats, VTach complexes, Shock/Pace spikes)
    for (let i = 0; i < state.events.length; i++) {
      const ev = state.events[i];
      const dt = tMs - ev.centerMs;
      if (Math.abs(dt) > 360) continue;

      if (ev.kind === "P") {
        mv += 0.17 * gaussian(dt, 22);
      } else if (ev.kind === "QRS") {
        mv -= 0.15 * gaussian(dt + 20, 7.5);
        mv += 1.2 * gaussian(dt, 9.5);
        mv -= 0.25 * gaussian(dt - 22, 8.5);
      } else if (ev.kind === "T") {
        const sigma = dt < 0 ? 42 : 30;
        mv += 0.32 * gaussian(dt, sigma);
      } else if (ev.kind === "VT") {
        // Wide, fast monomorphic VTach wave
        mv += 0.95 * gaussian(dt, 28) - 0.42 * gaussian(dt - 44, 24);
      } else if (ev.kind === "SPIKE") {
        // Sharp capacitive discharge artifact spike scaled by energy
        mv += ev.amp * gaussian(dt, 4.5);
      }
    }

    mv += Math.sin(tMs * 0.037) * 0.008;
    return mv;
  }

  function scheduleSinusBeat(centerMs) {
    state.events.push({ kind: "P", centerMs: centerMs - 150 });
    state.events.push({ kind: "QRS", centerMs });
    state.events.push({ kind: "T", centerMs: centerMs + 220 });
    state.lastBeatMs = centerMs;
  }

  function scheduleCapturedBeat(centerMs) {
    // Paced ventricular capture: pacing spike immediately followed by wide QRS + T
    state.events.push({ kind: "QRS", centerMs: centerMs + 35 });
    state.events.push({ kind: "T", centerMs: centerMs + 250 });
    state.lastBeatMs = centerMs;
  }

  /**
   * Fire capacitor discharge into the heart!
   */
  function firePulse(isAutoPace) {
    state.switchFlashMs = 220;
    state.capCharge = 0.08; // Capacitor discharges, then recharges rapidly

    const spikeAmp = isAutoPace ? 0.95 : Math.min(2.1, 0.75 + (params.energyJ / 360) * 1.35);
    state.events.push({ kind: "SPIKE", centerMs: state.tMs, amp: spikeAmp });

    if (isAutoPace) {
      // Demand pacemaker pulse captures a beat in bradycardia / sinus pause
      if (state.rhythm === "brady" || state.rhythm === "sinus") {
        scheduleCapturedBeat(state.tMs);
        state.nextNaturalBeatMs = state.tMs + 1750; // Reset natural escape timer
        state.feedbackKey = "p.fbAutoPace";
        state.feedbackVars = { ms: params.timingMs, bpm: Math.round(60000 / params.timingMs) };
      }
      syncUI();
      return;
    }

    // Manual pulse / defibrillation shock
    if (state.rhythm === "vfib") {
      if (params.energyJ >= 150) {
        state.rhythm = "resetting";
        state.resetUntilMs = state.tMs + 480;
        state.nextNaturalBeatMs = state.tMs + 680;
        state.feedbackKey = "p.fbVfibOk";
        state.feedbackVars = { e: params.energyJ };
      } else {
        state.feedbackKey = "p.fbVfibLow";
        state.feedbackVars = { e: params.energyJ };
      }
    } else if (state.rhythm === "vtach") {
      if (params.energyJ >= 100) {
        state.rhythm = "resetting";
        state.resetUntilMs = state.tMs + 420;
        state.nextNaturalBeatMs = state.tMs + 620;
        state.feedbackKey = "p.fbVtachOk";
        state.feedbackVars = { e: params.energyJ };
      } else {
        state.feedbackKey = "p.fbVtachLow";
        state.feedbackVars = { e: params.energyJ };
      }
    } else if (state.rhythm === "brady") {
      scheduleCapturedBeat(state.tMs);
      state.nextNaturalBeatMs = state.tMs + 1750;
      state.feedbackKey = "p.fbManualBeat";
      state.feedbackVars = { e: params.energyJ };
    } else {
      state.feedbackKey = "p.fbAlreadySinus";
      state.feedbackVars = { e: params.energyJ };
    }

    syncUI();
  }

  function setScenario(rhythmKey) {
    state.rhythm = rhythmKey;
    state.pendingDelayTimerMs = -1;
    state.events = [];
    state.feedbackVars = {};

    if (rhythmKey === "vfib") {
      state.feedbackKey = "p.fbScenVfib";
    } else if (rhythmKey === "vtach") {
      state.nextNaturalBeatMs = state.tMs + 120;
      state.feedbackKey = "p.fbScenVtach";
    } else if (rhythmKey === "brady") {
      state.lastBeatMs = state.tMs - 200;
      state.nextNaturalBeatMs = state.tMs + 1400;
      state.feedbackKey = "p.fbScenBrady";
    }

    document.querySelectorAll("#pace-scenarios .btn-preset").forEach((btn) => {
      btn.classList.toggle("is-selected", btn.dataset.rhythm === rhythmKey);
    });
    syncUI();
  }

  function getRhythmLabel() {
    switch (state.rhythm) {
      case "vfib": return Bio.t("p.stateVfib");
      case "vtach": return Bio.t("p.stateVtach");
      case "brady": return params.autoPace ? Bio.t("p.statePaced") : Bio.t("p.stateBrady");
      case "resetting": return Bio.t("p.stateReset");
      case "sinus": return Bio.t("p.stateSinus");
      default: return Bio.t("h.presetNormal");
    }
  }

  function syncUI() {
    const bpm = Math.round(60000 / params.timingMs);
    document.getElementById("val-energy").textContent = `${params.energyJ} J`;
    document.getElementById("val-timing").textContent = `${params.timingMs} ms (${bpm} BPM)`;

    stateReadout.textContent = getRhythmLabel();
    energyReadout.textContent = `${params.energyJ} J`;
    voltReadout.textContent = `${Math.round(capacitorVoltageV())} V`;
    feedbackEl.textContent = Bio.t(state.feedbackKey, state.feedbackVars);
  }

  function init() {
    ecgCanvas = document.getElementById("pace-ecg");
    circuitCanvas = document.getElementById("pace-circuit");
    energySlider = document.getElementById("slider-energy");
    timingSlider = document.getElementById("slider-timing");
    autoPaceToggle = document.getElementById("pace-autopace");

    stateReadout = document.getElementById("pace-state-readout");
    energyReadout = document.getElementById("pace-energy-readout");
    voltReadout = document.getElementById("pace-volt-readout");
    feedbackEl = document.getElementById("pace-feedback");

    energySlider.addEventListener("input", () => {
      params.energyJ = parseInt(energySlider.value, 10);
      syncUI();
    });
    timingSlider.addEventListener("input", () => {
      params.timingMs = parseInt(timingSlider.value, 10);
      syncUI();
    });
    autoPaceToggle.addEventListener("change", () => {
      params.autoPace = autoPaceToggle.checked;
      syncUI();
    });

    document.getElementById("pace-deliver-btn").addEventListener("click", () => {
      // Brief capacitor trigger delay proportional to timing slider (20–140 ms) so timing feels responsive
      const syncDelayMs = Math.round(params.timingMs * 0.08);
      state.pendingDelayTimerMs = syncDelayMs;
    });

    document.querySelectorAll("#pace-scenarios .btn-preset").forEach((btn) => {
      btn.addEventListener("click", () => setScenario(btn.dataset.rhythm));
    });

    // Pre-fill 4 seconds of chaotic VFib trace
    for (let t = -WINDOW_MS; t <= 0; t += 8) {
      state.samples.push({ t, mv: evaluateSignalMv(t) });
    }

    syncUI();
  }

  function update(dtSec) {
    const dtMs = dtSec * 1000;
    const targetT = state.tMs + dtMs;

    // Recharge visual capacitor smoothly after discharge
    state.capCharge = Math.min(1.0, state.capCharge + dtSec * 1.8);
    state.switchFlashMs = Math.max(0, state.switchFlashMs - dtMs);

    while (state.tMs < targetT) {
      state.tMs = Math.min(targetT, state.tMs + 6);

      // Handle manual timed discharge countdown
      if (state.pendingDelayTimerMs >= 0) {
        state.pendingDelayTimerMs -= 6;
        if (state.pendingDelayTimerMs < 0) {
          firePulse(false);
        }
      }

      // Transition out of post-shock refractory pause into Normal Sinus
      if (state.rhythm === "resetting" && state.tMs >= state.resetUntilMs) {
        state.rhythm = "sinus";
        syncUI();
      }

      // Schedule natural beats depending on active rhythm
      if (state.rhythm === "sinus" && state.tMs >= state.nextNaturalBeatMs) {
        scheduleSinusBeat(state.tMs + 160);
        state.nextNaturalBeatMs += 833; // 72 BPM
      } else if (state.rhythm === "vtach" && state.tMs >= state.nextNaturalBeatMs) {
        state.events.push({ kind: "VT", centerMs: state.tMs + 60 });
        state.lastBeatMs = state.tMs + 60;
        state.nextNaturalBeatMs += 364; // ~165 BPM
      } else if (state.rhythm === "brady" && state.tMs >= state.nextNaturalBeatMs) {
        scheduleSinusBeat(state.tMs + 160);
        state.nextNaturalBeatMs += 1760; // ~34 BPM slow escape
      }

      // Demand Auto-Pacemaker watchdog check
      if (
        params.autoPace &&
        (state.rhythm === "brady" || state.rhythm === "sinus") &&
        state.tMs - state.lastBeatMs >= params.timingMs
      ) {
        firePulse(true);
      }

      state.samples.push({ t: state.tMs, mv: evaluateSignalMv(state.tMs) });
    }

    const minT = state.tMs - WINDOW_MS - 400;
    while (state.samples.length > 2 && state.samples[0].t < minT) {
      state.samples.shift();
    }
    while (state.events.length > 0 && state.events[0].centerMs < minT) {
      state.events.shift();
    }
  }

  function drawEcg() {
    const W = 760;
    const H = 320;
    const ctx = Bio.fitCanvas(ecgCanvas, W, H);

    const pad = { left: 58, right: 20, top: 24, bottom: 38 };
    const pw = W - pad.left - pad.right;
    const ph = H - pad.top - pad.bottom;

    const mvMin = -0.8;
    const mvMax = 1.8;
    const mapY = (mv) => pad.top + ((mvMax - mv) / (mvMax - mvMin)) * ph;
    const tEnd = state.tMs;
    const tStart = tEnd - WINDOW_MS;
    const mapX = (t) => pad.left + ((t - tStart) / WINDOW_MS) * pw;

    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);
    Bio.drawGrid(ctx, pad.left, pad.top, pw, ph, 20, 13, 5);

    // Y-axis ticks & label (mV)
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "11px ui-monospace, monospace";
    ctx.textAlign = "right";
    [-0.5, 0, 0.5, 1.0, 1.5].forEach((v) => {
      ctx.fillText(v.toFixed(1), pad.left - 8, mapY(v) + 4);
    });

    ctx.save();
    ctx.translate(16, pad.top + ph / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = "center";
    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText(Bio.t("p.axisY"), 0, 0);
    ctx.restore();

    // X-axis ticks (ms)
    ctx.textAlign = "center";
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "11px ui-monospace, monospace";
    for (let ms = 0; ms <= WINDOW_MS; ms += 1000) {
      const x = pad.left + (ms / WINDOW_MS) * pw;
      const label = ms === WINDOW_MS ? "0 ms" : `-${WINDOW_MS - ms}`;
      ctx.fillText(label, x, pad.top + ph + 16);
    }
    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText(Bio.t("p.axisX"), pad.left + pw / 2, H - 6);

    // Waveform
    ctx.save();
    ctx.beginPath();
    ctx.rect(pad.left, pad.top, pw, ph);
    ctx.clip();

    const isIrregular = state.rhythm === "vfib" || state.rhythm === "vtach";
    ctx.strokeStyle = isIrregular ? Bio.COLORS.warn : ACCENT;
    ctx.lineWidth = 2.4;
    ctx.lineJoin = "round";
    ctx.shadowColor = isIrregular ? "rgba(255, 107, 122, 0.45)" : "rgba(0, 229, 163, 0.45)";
    ctx.shadowBlur = 7;

    ctx.beginPath();
    state.samples.forEach((pt, idx) => {
      const px = mapX(pt.t);
      const py = mapY(pt.mv);
      if (idx === 0) ctx.moveTo(px, py);
      else ctx.lineTo(px, py);
    });
    ctx.stroke();

    // Highlight discharge spikes
    ctx.shadowBlur = 0;
    ctx.font = "bold 11px ui-monospace, monospace";
    ctx.textAlign = "center";
    state.events.forEach((ev) => {
      if (ev.kind === "SPIKE" && ev.centerMs >= tStart && ev.centerMs <= tEnd) {
        const x = mapX(ev.centerMs);
        ctx.strokeStyle = "#e8eef6";
        ctx.lineWidth = 1.4;
        ctx.setLineDash([3, 3]);
        ctx.beginPath();
        ctx.moveTo(x, pad.top + 16);
        ctx.lineTo(x, pad.top + ph);
        ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = "#e8eef6";
        ctx.fillText(Bio.t("p.spikeTag"), x, pad.top + 13);
      }
    });

    ctx.restore();
  }

  /**
   * Draw simple DC Charger -> Capacitor (C) -> Switch -> Heart Load (50 Ω) circuit.
   */
  function drawCircuit() {
    const W = 420;
    const H = 190;
    const ctx = Bio.fitCanvas(circuitCanvas, W, H);
    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);

    const topY = 44;
    const botY = 148;
    const discharging = state.switchFlashMs > 0;

    // Main loop wires
    ctx.strokeStyle = discharging ? ACCENT : "#48607a";
    ctx.lineWidth = discharging ? 2.4 : 1.7;
    ctx.beginPath();
    ctx.moveTo(52, topY);
    ctx.lineTo(222, topY);
    ctx.moveTo(264, topY);
    ctx.lineTo(360, topY);
    ctx.lineTo(360, 74);
    ctx.moveTo(360, 120);
    ctx.lineTo(360, botY);
    ctx.lineTo(52, botY);
    ctx.lineTo(52, 114);
    ctx.moveTo(52, 76);
    ctx.lineTo(52, topY);
    ctx.stroke();

    // 1. DC Power Supply (left)
    ctx.strokeStyle = "#90a4ba";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(38, 86);
    ctx.lineTo(66, 86);
    ctx.moveTo(45, 96);
    ctx.lineTo(59, 96);
    ctx.moveTo(38, 106);
    ctx.lineTo(66, 106);
    ctx.stroke();
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "10px ui-monospace, monospace";
    ctx.textAlign = "center";
    ctx.fillText(Bio.t("p.circSupply"), 52, 170);

    // 2. Storage Capacitor Bank (middle-left, x=158)
    const capX = 158;
    ctx.strokeStyle = "#48607a";
    ctx.lineWidth = 1.7;
    ctx.beginPath();
    ctx.moveTo(capX, topY);
    ctx.lineTo(capX, 82);
    ctx.moveTo(capX, 112);
    ctx.lineTo(capX, botY);
    ctx.stroke();

    // Capacitor plates + animated charge fill
    ctx.fillStyle = "rgba(0, 229, 163, " + (0.15 + 0.65 * state.capCharge).toFixed(2) + ")";
    const fillH = 22 * state.capCharge;
    ctx.fillRect(capX - 18, 108 - fillH, 36, fillH);

    ctx.strokeStyle = ACCENT;
    ctx.lineWidth = 2.6;
    ctx.beginPath();
    ctx.moveTo(capX - 20, 82);
    ctx.lineTo(capX + 20, 82);
    ctx.moveTo(capX - 20, 112);
    ctx.lineTo(capX + 20, 112);
    ctx.stroke();

    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "bold 11px ui-monospace, monospace";
    ctx.fillText(`C = ${CAP_UF} µF`, capX, 28);
    ctx.fillStyle = ACCENT;
    ctx.fillText(`${Math.round(capacitorVoltageV())} V`, capX, 170);

    // 3. Discharge Switch (x=222..264)
    ctx.strokeStyle = discharging ? ACCENT : "#e8eef6";
    ctx.lineWidth = 2.4;
    ctx.beginPath();
    ctx.arc(222, topY, 3.2, 0, Math.PI * 2);
    ctx.arc(264, topY, 3.2, 0, Math.PI * 2);
    ctx.stroke();

    ctx.beginPath();
    ctx.moveTo(222, topY);
    if (discharging) {
      ctx.lineTo(264, topY); // Switch closed!
    } else {
      ctx.lineTo(258, topY - 16); // Switch open
    }
    ctx.stroke();

    ctx.fillStyle = discharging ? ACCENT : Bio.COLORS.muted;
    ctx.font = "10px ui-monospace, monospace";
    ctx.fillText(discharging ? Bio.t("p.circDischarge") : Bio.t("p.circSwitch"), 243, 24);

    // 4. Heart / Thorax Load Resistor (right, x=360)
    ctx.strokeStyle = discharging ? ACCENT : "#90a4ba";
    ctx.lineWidth = discharging ? 2.5 : 1.8;
    ctx.beginPath();
    ctx.moveTo(360, 74);
    for (let i = 0; i < 6; i++) {
      const yy = 74 + ((i + 0.5) * 46) / 6;
      const dx = i % 2 === 0 ? -8 : 8;
      ctx.lineTo(360 + dx, yy);
    }
    ctx.lineTo(360, 120);
    ctx.stroke();

    ctx.fillStyle = discharging ? ACCENT : Bio.COLORS.text;
    ctx.font = "bold 11px ui-monospace, monospace";
    ctx.fillText(Bio.t("p.circHeart"), 360, 28);
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "10px ui-monospace, monospace";
    ctx.fillText(`R = ${R_LOAD_OHM} Ω`, 360, 170);
  }

  function draw() {
    drawEcg();
    drawCircuit();
  }

  Bio.registerModule("pacemaker", {
    init,
    update,
    draw,
    onShow: draw,
    onLangChange: () => {
      syncUI();
      draw();
    }
  });
})(window.BioCircuits);
