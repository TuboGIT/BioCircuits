/**
 * neuron.js — Module 1: Neuron as an RC Circuit
 *
 * Physics Model:
 * A simplified Hodgkin-Huxley membrane patch wired as a parallel RC circuit:
 *   C_m * (dV/dt) = I_stim - I_leak - I_Na - I_K
 *
 * Unit harmony:
 *   - Voltage V in mV (millivolts)
 *   - Time t in ms (milliseconds)
 *   - Capacitance C_m in µF (microfarads)
 *   - Resistance R_m in kΩ (kilohms)  --> tau = R_m * C_m is directly in ms!
 *   - Conductance g in mS (millisiemens), where g_leak = 1 / R_m
 *   - Current I in µA (microamperes)
 */
(function (Bio) {
  "use strict";

  const ACCENT = Bio.COLORS.accent;
  const HISTORY_MS = 80;       // Width of the oscilloscope window in ms
  const SIM_MS_PER_SEC = 18;   // Slow-motion speed: 18 ms of neural time per 1 s real time
  const SUBSTEP_MS = 0.025;    // Small numerical step for rock-solid ODE stability

  // Reversal potentials (batteries in the equivalent circuit)
  const E_NA = 50.0;   // Sodium battery (mV)
  const E_K = -82.0;   // Potassium battery (mV)
  const E_L = -59.4;   // Leak battery (mV) — balances resting Na/K currents near -70 mV

  // Simulation state
  const state = {
    V: -70.0,
    m: 0.0529,
    h: 0.5961,
    n: 0.3177,
    tMs: 0,
    pulseRemainingMs: 0,
    // Latest instantaneous currents (µA) for circuit diagram animation
    iNa: 0,
    iK: 0,
    iLeak: 0,
    iStimActive: 0,
    // Ring buffer of { t, V } samples
    samples: []
  };

  // User-controlled parameters
  const params = {
    rmKOhm: 50,      // kΩ
    cmUf: 0.20,      // µF
    gNaMs: 8.0,      // mS
    gKMs: 2.4,       // mS
    iStimUa: 0.80,   // µA
    continuous: false
  };

  // DOM references
  let graphCanvas, circuitCanvas;
  let vmReadout, tauReadout, phaseReadout, circuitChip;

  /**
   * Hodgkin-Huxley voltage-dependent rate functions, shifted so u = 0 at -70 mV.
   */
  function safeExpRatio(num, denom) {
    // Avoid 0/0 singularity when denom approaches 0
    if (Math.abs(denom) < 1e-6) return 1.0;
    return num / denom;
  }

  function stepHodgkinHuxley(dtMs) {
    const u = state.V + 70.0;

    // Sodium activation (m)
    const alphaM = safeExpRatio(0.1 * (25 - u), Math.exp((25 - u) / 10) - 1) || 1.0;
    const betaM = 4.0 * Math.exp(-u / 18.0);

    // Sodium inactivation (h)
    const alphaH = 0.07 * Math.exp(-u / 20.0);
    const betaH = 1.0 / (Math.exp((30 - u) / 10.0) + 1.0);

    // Potassium activation (n)
    const alphaN = Math.abs(10 - u) < 1e-5
      ? 0.1
      : (0.01 * (10 - u)) / (Math.exp((10 - u) / 10.0) - 1.0);
    const betaN = 0.125 * Math.exp(-u / 80.0);

    const alphaMSafe = Math.abs(25 - u) < 1e-5
      ? 1.0
      : (0.1 * (25 - u)) / (Math.exp((25 - u) / 10.0) - 1.0);

    // Advance gating variables
    state.m += dtMs * (alphaMSafe * (1 - state.m) - betaM * state.m);
    state.h += dtMs * (alphaH * (1 - state.h) - betaH * state.h);
    state.n += dtMs * (alphaN * (1 - state.n) - betaN * state.n);

    // Clamp gates to [0, 1]
    state.m = Math.max(0, Math.min(1, state.m));
    state.h = Math.max(0, Math.min(1, state.h));
    state.n = Math.max(0, Math.min(1, state.n));

    // Membrane conductances (mS)
    const gLeak = 1.0 / params.rmKOhm; // 1 / kΩ = mS
    const gNa = params.gNaMs * Math.pow(state.m, 3) * state.h;
    const gK = params.gKMs * Math.pow(state.n, 4);

    // Ionic currents (µA)
    const iLeak = gLeak * (state.V - E_L);
    const iNa = gNa * (state.V - E_NA);
    const iK = gK * (state.V - E_K);

    // Applied stimulus current (µA)
    let iStim = 0;
    if (params.continuous || state.pulseRemainingMs > 0) {
      iStim = params.iStimUa;
      if (state.pulseRemainingMs > 0) {
        state.pulseRemainingMs = Math.max(0, state.pulseRemainingMs - dtMs);
      }
    }

    // RC membrane equation: C_m * dV/dt = I_stim - (I_Na + I_K + I_leak)
    const dVdt = (iStim - iNa - iK - iLeak) / params.cmUf;
    state.V += dtMs * dVdt;
    state.V = Math.max(-105, Math.min(65, state.V));
    state.tMs += dtMs;

    state.iNa = iNa;
    state.iK = iK;
    state.iLeak = iLeak;
    state.iStimActive = iStim;
  }

  /**
   * Determine the current physiological phase label for the live badge.
   */
  function getPhaseLabel() {
    if (state.V > 10) return Bio.t("n.phasePeak");
    if (state.V > -55 && state.iNa < -0.5) return Bio.t("n.phaseDepol");
    if (state.V > -65 && state.iK > 0.5) return Bio.t("n.phaseRepol");
    if (state.V < -73) return Bio.t("n.phaseHyper");
    if (state.iStimActive > 0) return Bio.t("n.phaseCharging");
    return Bio.t("n.phaseRest");
  }

  function resetSimulation() {
    state.V = -70.0;
    state.m = 0.0529;
    state.h = 0.5961;
    state.n = 0.3177;
    state.tMs = 0;
    state.pulseRemainingMs = 0;
    state.samples = [];
    // Pre-fill a calm resting baseline across the oscilloscope
    for (let t = -HISTORY_MS; t <= 0; t += 0.25) {
      state.samples.push({ t, V: -70.0 });
    }
  }

  function bindControls() {
    const rmSlider = document.getElementById("slider-rm");
    const cmSlider = document.getElementById("slider-cm");
    const gnaSlider = document.getElementById("slider-gna");
    const gkSlider = document.getElementById("slider-gk");
    const istimSlider = document.getElementById("slider-istim");
    const continuousToggle = document.getElementById("neuron-continuous");

    const valRm = document.getElementById("val-rm");
    const valCm = document.getElementById("val-cm");
    const valGna = document.getElementById("val-gna");
    const valGk = document.getElementById("val-gk");
    const valIstim = document.getElementById("val-istim");

    function syncParams() {
      params.rmKOhm = parseFloat(rmSlider.value);
      params.cmUf = parseFloat(cmSlider.value);
      params.gNaMs = parseFloat(gnaSlider.value);
      params.gKMs = parseFloat(gkSlider.value);
      params.iStimUa = parseFloat(istimSlider.value);
      params.continuous = continuousToggle.checked;

      valRm.textContent = `${params.rmKOhm.toFixed(0)} kΩ`;
      valCm.textContent = `${params.cmUf.toFixed(2)} µF`;
      valGna.textContent = `${params.gNaMs.toFixed(1)} mS`;
      valGk.textContent = `${params.gKMs.toFixed(1)} mS`;
      valIstim.textContent = `${params.iStimUa.toFixed(2)} µA`;

      const tau = params.rmKOhm * params.cmUf;
      tauReadout.textContent = `${tau.toFixed(1)} ms`;
      circuitChip.textContent = `τ = ${tau.toFixed(1)} ms`;
    }

    [rmSlider, cmSlider, gnaSlider, gkSlider, istimSlider, continuousToggle].forEach((el) => {
      el.addEventListener("input", syncParams);
    });

    document.getElementById("neuron-stim-btn").addEventListener("click", () => {
      state.pulseRemainingMs = 6.0; // Inject a 6 ms current pulse
    });

    document.getElementById("neuron-reset-btn").addEventListener("click", () => {
      continuousToggle.checked = false;
      params.continuous = false;
      resetSimulation();
    });

    syncParams();
  }

  function init() {
    graphCanvas = document.getElementById("neuron-graph");
    circuitCanvas = document.getElementById("neuron-circuit");
    vmReadout = document.getElementById("neuron-vm-readout");
    tauReadout = document.getElementById("neuron-tau-readout");
    phaseReadout = document.getElementById("neuron-phase-readout");
    circuitChip = document.getElementById("neuron-circuit-chip");

    bindControls();
    resetSimulation();
  }

  function update(dtSec) {
    const advanceMs = dtSec * SIM_MS_PER_SEC;
    const steps = Math.max(1, Math.round(advanceMs / SUBSTEP_MS));
    const h = advanceMs / steps;

    for (let i = 0; i < steps; i++) {
      stepHodgkinHuxley(h);
    }

    state.samples.push({ t: state.tMs, V: state.V });

    // Trim samples older than the visible time window
    const minT = state.tMs - HISTORY_MS;
    while (state.samples.length > 2 && state.samples[0].t < minT - 2) {
      state.samples.shift();
    }

    // Update live numeric readouts
    vmReadout.textContent = `${state.V.toFixed(1)} mV`;
    phaseReadout.textContent = getPhaseLabel();
  }

  function drawGraph() {
    const W = 760;
    const H = 340;
    const ctx = Bio.fitCanvas(graphCanvas, W, H);

    // Plot margins
    const pad = { left: 62, right: 20, top: 22, bottom: 40 };
    const pw = W - pad.left - pad.right;
    const ph = H - pad.top - pad.bottom;

    const vMin = -100;
    const vMax = 60;
    const mapY = (v) => pad.top + ((vMax - v) / (vMax - vMin)) * ph;
    const tEnd = state.tMs;
    const tStart = tEnd - HISTORY_MS;
    const mapX = (t) => pad.left + ((t - tStart) / HISTORY_MS) * pw;

    // Background + grid
    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);
    Bio.drawGrid(ctx, pad.left, pad.top, pw, ph, 16, 8, 2);

    // Reference voltage lines (-70 mV resting, -55 mV threshold, 0 mV, +40 mV)
    const refs = [
      { v: 40, label: "+40 mV", dashed: false, color: "rgba(144,164,186,0.22)" },
      { v: 0, label: "0 mV", dashed: false, color: "rgba(144,164,186,0.22)" },
      { v: -55, label: Bio.t("n.refThresh"), dashed: true, color: "rgba(232,238,246,0.45)" },
      { v: -70, label: Bio.t("n.refRest"), dashed: true, color: "rgba(0,229,163,0.32)" }
    ];

    ctx.font = "11px ui-monospace, Consolas, monospace";
    refs.forEach((ref) => {
      const y = Math.round(mapY(ref.v)) + 0.5;
      ctx.save();
      ctx.strokeStyle = ref.color;
      ctx.lineWidth = 1;
      if (ref.dashed) ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(pad.left, y);
      ctx.lineTo(pad.left + pw, y);
      ctx.stroke();
      ctx.fillStyle = Bio.COLORS.muted;
      ctx.textAlign = "right";
      ctx.fillText(ref.label, pad.left + pw - 6, y - 4);
      ctx.restore();
    });

    // Y-axis ticks & label (mV)
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.textAlign = "right";
    [-100, -70, -40, 0, 40].forEach((v) => {
      ctx.fillText(`${v}`, pad.left - 8, mapY(v) + 4);
    });

    ctx.save();
    ctx.translate(16, pad.top + ph / 2);
    ctx.rotate(-Math.PI / 2);
    ctx.textAlign = "center";
    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText(Bio.t("n.axisY"), 0, 0);
    ctx.restore();

    // X-axis ticks & label (ms)
    ctx.textAlign = "center";
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.font = "11px ui-monospace, Consolas, monospace";
    for (let dt = 0; dt <= HISTORY_MS; dt += 10) {
      const x = pad.left + (dt / HISTORY_MS) * pw;
      const relLabel = dt === HISTORY_MS ? "0 ms" : `-${HISTORY_MS - dt}`;
      ctx.fillText(relLabel, x, pad.top + ph + 16);
    }
    ctx.fillStyle = Bio.COLORS.text;
    ctx.font = "12px system-ui, sans-serif";
    ctx.fillText(Bio.t("n.axisX"), pad.left + pw / 2, H - 6);

    // Draw membrane voltage trace
    if (state.samples.length > 1) {
      ctx.save();
      ctx.beginPath();
      ctx.rect(pad.left, pad.top, pw, ph);
      ctx.clip();

      ctx.strokeStyle = ACCENT;
      ctx.lineWidth = 2.5;
      ctx.lineJoin = "round";
      ctx.shadowColor = "rgba(0, 229, 163, 0.45)";
      ctx.shadowBlur = 8;

      ctx.beginPath();
      state.samples.forEach((pt, idx) => {
        const px = mapX(pt.t);
        const py = mapY(pt.V);
        if (idx === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
      });
      ctx.stroke();

      // Glowing live tip dot
      const last = state.samples[state.samples.length - 1];
      ctx.shadowBlur = 12;
      ctx.fillStyle = ACCENT;
      ctx.beginPath();
      ctx.arc(mapX(last.t), mapY(last.V), 4.2, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();
    }

    // Highlight stimulus active indicator
    if (state.iStimActive > 0) {
      ctx.fillStyle = "rgba(0, 229, 163, 0.16)";
      ctx.fillRect(pad.left + pw - 96, pad.top + 8, 88, 22);
      ctx.strokeStyle = ACCENT;
      ctx.strokeRect(pad.left + pw - 96, pad.top + 8, 88, 22);
      ctx.fillStyle = ACCENT;
      ctx.font = "bold 11px ui-monospace, monospace";
      ctx.textAlign = "center";
      ctx.fillText(Bio.t("n.stimOn"), pad.left + pw - 52, pad.top + 23);
    }
  }

  /**
   * Draw a small interactive RC + ion-channel schematic that reacts to sliders
   * and live currents.
   */
  function drawCircuit() {
    const W = 420;
    const H = 220;
    const ctx = Bio.fitCanvas(circuitCanvas, W, H);

    ctx.fillStyle = Bio.COLORS.bg;
    ctx.fillRect(0, 0, W, H);

    const topY = 38;
    const botY = 182;
    const branchesX = [60, 145, 225, 305, 375];

    // Top intracellular bus (V_m) and bottom extracellular ground bus (0 mV)
    ctx.strokeStyle = "#48607a";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(branchesX[0], topY);
    ctx.lineTo(branchesX[4], topY);
    ctx.moveTo(branchesX[0], botY);
    ctx.lineTo(branchesX[4], botY);
    ctx.stroke();

    ctx.font = "11px ui-monospace, monospace";
    ctx.fillStyle = ACCENT;
    ctx.textAlign = "left";
    ctx.fillText(Bio.t("n.circIntra", { v: state.V.toFixed(1) }), 56, 22);
    ctx.fillStyle = Bio.COLORS.muted;
    ctx.fillText(Bio.t("n.circExtra"), 56, 204);

    // Helper: vertical wire + resistor zigzag
    function drawBranch(x, color, label, sublabel, isActive) {
      ctx.save();
      ctx.strokeStyle = color;
      ctx.lineWidth = isActive ? 2.4 : 1.6;

      // Top wire
      ctx.beginPath();
      ctx.moveTo(x, topY);
      ctx.lineTo(x, 76);
      ctx.moveTo(x, 122);
      ctx.lineTo(x, 142);
      ctx.moveTo(x, 158);
      ctx.lineTo(x, botY);
      ctx.stroke();

      // Resistor zigzag
      ctx.beginPath();
      ctx.moveTo(x, 76);
      for (let i = 0; i < 6; i++) {
        const yy = 76 + ((i + 0.5) * 46) / 6;
        const dx = i % 2 === 0 ? -7 : 7;
        ctx.lineTo(x + dx, yy);
      }
      ctx.lineTo(x, 122);
      ctx.stroke();

      // Battery symbol
      ctx.beginPath();
      ctx.moveTo(x - 10, 142);
      ctx.lineTo(x + 10, 142);
      ctx.moveTo(x - 5, 150);
      ctx.lineTo(x + 5, 150);
      ctx.stroke();

      // Labels
      ctx.fillStyle = isActive ? ACCENT : Bio.COLORS.text;
      ctx.textAlign = "center";
      ctx.font = "bold 11px ui-monospace, monospace";
      ctx.fillText(label, x, 66);
      ctx.fillStyle = Bio.COLORS.muted;
      ctx.font = "10px ui-monospace, monospace";
      ctx.fillText(sublabel, x, 173);
      ctx.restore();
    }

    // 1. Stimulus Current Source (I_stim)
    {
      const x = branchesX[0];
      const active = state.iStimActive > 0;
      ctx.save();
      ctx.strokeStyle = active ? ACCENT : "#48607a";
      ctx.lineWidth = active ? 2.5 : 1.6;
      ctx.beginPath();
      ctx.moveTo(x, topY);
      ctx.lineTo(x, 90);
      ctx.moveTo(x, 130);
      ctx.lineTo(x, botY);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(x, 110, 18, 0, Math.PI * 2);
      ctx.fillStyle = active ? "rgba(0, 229, 163, 0.16)" : "#0d141e";
      ctx.fill();
      ctx.stroke();

      // Upward current arrow
      ctx.beginPath();
      ctx.moveTo(x, 120);
      ctx.lineTo(x, 99);
      ctx.moveTo(x - 5, 105);
      ctx.lineTo(x, 99);
      ctx.lineTo(x + 5, 105);
      ctx.stroke();

      ctx.fillStyle = active ? ACCENT : Bio.COLORS.muted;
      ctx.textAlign = "center";
      ctx.font = "bold 10px ui-monospace, monospace";
      ctx.fillText("I_stim", x, 66);
      ctx.fillText(`${params.iStimUa.toFixed(2)}µA`, x, 145);
      ctx.restore();
    }

    // 2. Membrane Capacitor (C_m) — gap visually scales with capacitance
    {
      const x = branchesX[1];
      const plateGap = Math.max(6, Math.min(18, 18 - params.cmUf * 11));
      const midY = (topY + botY) / 2;
      ctx.save();
      ctx.strokeStyle = ACCENT;
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(x, topY);
      ctx.lineTo(x, midY - plateGap / 2);
      ctx.moveTo(x - 14, midY - plateGap / 2);
      ctx.lineTo(x + 14, midY - plateGap / 2);

      ctx.moveTo(x - 14, midY + plateGap / 2);
      ctx.lineTo(x + 14, midY + plateGap / 2);
      ctx.moveTo(x, midY + plateGap / 2);
      ctx.lineTo(x, botY);
      ctx.stroke();

      ctx.fillStyle = Bio.COLORS.text;
      ctx.textAlign = "center";
      ctx.font = "bold 11px ui-monospace, monospace";
      ctx.fillText("Cm", x, 66);
      ctx.fillStyle = ACCENT;
      ctx.font = "10px ui-monospace, monospace";
      ctx.fillText(`${params.cmUf.toFixed(2)}µF`, x, 173);
      ctx.restore();
    }

    // 3. Leak Resistance (R_m)
    drawBranch(branchesX[2], "#7a90a8", "Rm", `${params.rmKOhm}kΩ`, false);

    // 4. Sodium Channel (g_Na) — glows when Na+ rushes in
    const naOpen = Math.abs(state.iNa) > 0.6;
    drawBranch(
      branchesX[3],
      naOpen ? ACCENT : "#6b8299",
      "gNa",
      `${params.gNaMs.toFixed(1)}mS`,
      naOpen
    );

    // 5. Potassium Channel (g_K) — glows when K+ flows out
    const kOpen = Math.abs(state.iK) > 0.6;
    drawBranch(
      branchesX[4],
      kOpen ? "#e8eef6" : "#6b8299",
      "gK",
      `${params.gKMs.toFixed(1)}mS`,
      kOpen
    );
  }

  function draw() {
    drawGraph();
    drawCircuit();
  }

  Bio.registerModule("neuron", {
    init,
    update,
    draw,
    onShow: draw,
    onLangChange: () => {
      if (phaseReadout) phaseReadout.textContent = getPhaseLabel();
      draw();
    }
  });
})(window.BioCircuits);
