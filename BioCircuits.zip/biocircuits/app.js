/**
 * app.js — BioCircuits Application Shell & Shared Utilities
 *
 * Responsibilities:
 * 1. Manage top-level module tab switching (Neuron, Heart, Nerve, Pacemaker).
 * 2. Run a single, clean 60 fps requestAnimationFrame loop that updates and
 *    renders whichever module is currently active.
 * 3. Provide beginner-friendly helpers for HiDPI (Retina) <canvas> scaling
 *    and oscilloscope grid drawing.
 */
(function (global) {
  "use strict";

  const modules = {};
  let activeModuleId = "neuron";
  let lastTimestamp = null;

  /**
   * Register a module controller with { init(), update(dtSec), draw() }.
   */
  function registerModule(id, controller) {
    modules[id] = controller;
  }

  /**
   * Switch the visible module section and update active tab styling.
   */
  function switchModule(id) {
    if (!modules[id]) return;
    activeModuleId = id;

    // Toggle nav buttons
    document.querySelectorAll(".nav-tab").forEach((btn) => {
      const isMatch = btn.dataset.module === id;
      btn.classList.toggle("is-active", isMatch);
      btn.setAttribute("aria-selected", String(isMatch));
    });

    // Toggle section visibility
    document.querySelectorAll(".module").forEach((section) => {
      const isMatch = section.id === "module-" + id;
      section.hidden = !isMatch;
      section.classList.toggle("is-active", isMatch);
    });

    // Resize canvases for the newly shown module and render one frame immediately
    if (typeof modules[id].onShow === "function") {
      modules[id].onShow();
    }
    modules[id].draw();
  }

  /**
   * Prepare a <canvas> for crisp rendering on high-DPI displays while keeping
   * logical CSS pixel coordinates consistent.
   */
  function fitCanvas(canvas, logicalWidth, logicalHeight) {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const targetW = Math.round(logicalWidth * dpr);
    const targetH = Math.round(logicalHeight * dpr);

    if (canvas.width !== targetW || canvas.height !== targetH) {
      canvas.width = targetW;
      canvas.height = targetH;
    }

    const ctx = canvas.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return ctx;
  }

  /**
   * Draw a subtle dark oscilloscope grid on a canvas.
   */
  function drawGrid(ctx, x, y, w, h, cols, rows, majorEvery) {
    ctx.save();
    ctx.lineWidth = 1;

    for (let i = 0; i <= cols; i++) {
      const px = Math.round(x + (w * i) / cols) + 0.5;
      const isMajor = majorEvery && i % majorEvery === 0;
      ctx.strokeStyle = isMajor ? "rgba(144, 164, 186, 0.16)" : "rgba(144, 164, 186, 0.06)";
      ctx.beginPath();
      ctx.moveTo(px, y);
      ctx.lineTo(px, y + h);
      ctx.stroke();
    }

    for (let j = 0; j <= rows; j++) {
      const py = Math.round(y + (h * j) / rows) + 0.5;
      const isMajor = majorEvery && j % majorEvery === 0;
      ctx.strokeStyle = isMajor ? "rgba(144, 164, 186, 0.16)" : "rgba(144, 164, 186, 0.06)";
      ctx.beginPath();
      ctx.moveTo(x, py);
      ctx.lineTo(x + w, py);
      ctx.stroke();
    }

    ctx.restore();
  }

  /**
   * Main 60 fps animation loop driven by requestAnimationFrame.
   */
  function tick(timestamp) {
    if (lastTimestamp === null) {
      lastTimestamp = timestamp;
    }
    // Clamp delta time so switching browser tabs never causes huge physics jumps
    const dtSec = Math.min((timestamp - lastTimestamp) / 1000, 0.05);
    lastTimestamp = timestamp;

    const current = modules[activeModuleId];
    if (current) {
      current.update(dtSec);
      current.draw();
    }

    requestAnimationFrame(tick);
  }

  /**
   * Shorthand translation lookup delegating to BioCircuits.i18n.t().
   */
  function t(key, vars) {
    if (global.BioCircuits && global.BioCircuits.i18n) {
      return global.BioCircuits.i18n.t(key, vars);
    }
    return key;
  }

  /**
   * Initialize all registered modules and wire up navigation once DOM is ready.
   */
  document.addEventListener("DOMContentLoaded", () => {
    if (global.BioCircuits && global.BioCircuits.i18n) {
      global.BioCircuits.i18n.init(() => {
        Object.keys(modules).forEach((id) => {
          if (typeof modules[id].onLangChange === "function") {
            modules[id].onLangChange();
          }
        });
        if (modules[activeModuleId]) {
          modules[activeModuleId].draw();
        }
      });
    }

    Object.keys(modules).forEach((id) => {
      if (typeof modules[id].init === "function") {
        modules[id].init();
      }
    });

    document.querySelectorAll(".nav-tab").forEach((btn) => {
      btn.addEventListener("click", () => {
        switchModule(btn.dataset.module);
      });
    });

    switchModule("neuron");
    requestAnimationFrame(tick);
  });

  // Expose shared namespace (works offline over file:// without ES module CORS issues)
  global.BioCircuits = Object.assign(global.BioCircuits || {}, {
    registerModule,
    switchModule,
    fitCanvas,
    drawGrid,
    t,
    COLORS: {
      bg: "#080c12",
      panel: "#111824",
      border: "#223044",
      text: "#e8eef6",
      muted: "#90a4ba",
      dim: "#64788f",
      accent: "#00e5a3",
      accentSoft: "rgba(0, 229, 163, 0.2)",
      warn: "#ff6b7a"
    }
  });
})(window);
